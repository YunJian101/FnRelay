$root = Split-Path -Parent $PSScriptRoot
"file-ok PSScriptRoot=$PSScriptRoot" | Set-Content -Path (Join-Path $root 'build\wtfile.txt') -Encoding utf8
Start-Sleep -Seconds 10
