$ErrorActionPreference = 'Continue'

$root = Split-Path -Parent $PSScriptRoot
$doneFile = Join-Path $root 'build\oauth194.done'
$stateFile = Join-Path $root 'build\oauth194.state.log'
$pending = Join-Path $env:USERPROFILE '.config\trim-cli\profiles\fn194.oauth-pending.json'

Remove-Item $doneFile -ErrorAction SilentlyContinue
Remove-Item $pending -Force -ErrorAction SilentlyContinue
'starting' | Set-Content -Path $stateFile -Encoding utf8

Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ' fnOS OAuth login (trim-cli)' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ''
Write-Host '1. A browser should open the authorization page.'
Write-Host '2. Sign in to fnOS and approve.'
Write-Host '3. Paste the one-time code here and press Enter.'
Write-Host ''
Write-Host 'This window is only for this authorization.'
Write-Host ''

$cli = 'C:\Users\SYanB\.dsh\skills\fnos\bin\trim-cli-windows-x64.exe'
& $cli --profile fn194 --host 192.168.11.194 --scheme https --tls-insecure login
$exitCode = $LASTEXITCODE
"exit=$exitCode" | Add-Content -Path $stateFile -Encoding utf8
"exit=$exitCode" | Set-Content -Path $doneFile -Encoding utf8

Write-Host ''
Write-Host "Login process ended (exit=$exitCode)." -ForegroundColor Yellow
Read-Host 'Press Enter to close'
